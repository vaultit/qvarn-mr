import json
import threading

from qvarnmq import Helpers, QvarnException


class Job(object):
    def __init__(self, qvarn_api_utils, job_resource):
        self._qvarn_api_utils = qvarn_api_utils
        self._keys = list(job_resource.keys())
        self._lock = threading.Lock()

        for key, value in job_resource.items():
            if key == 'parameters':
                continue

            setattr(self, key, value)

        self.parameters = Helpers.parameters_from_qvarn(
            job_resource['parameters'])

    ##########
    # PUBLIC #
    ##########

    def update(self, data):
        for key, value in data.items():
            setattr(self, key, value)

    def update_to_qvarn(self):
        self._lock.acquire()

        try:
            new_job_resource = self._qvarn_api_utils.update_resource(
                'jobs', self.id, self._to_qvarn())
        except QvarnException as error:
            raise error
        else:
            self.revision = new_job_resource['revision']
        finally:
            self._lock.release()

    def to_json(self):
        job_resource = {}
        for key in self._keys:
            job_resource[key] = getattr(self, key)

        return job_resource

    def __str__(self):
        job_resource = {}
        for key in self._keys:
            job_resource[key] = getattr(self, key)

        return json.dumps(job_resource, indent=4)

    ###########
    # PRIVATE #
    ###########

    def _to_qvarn(self):
        job_resource = {
            'parameters': Helpers.parameters_to_qvarn(self.parameters)
        }

        for key in self._keys:
            if key in ['id', 'type', 'parameters']:
                continue

            job_resource[key] = getattr(self, key)

        return job_resource

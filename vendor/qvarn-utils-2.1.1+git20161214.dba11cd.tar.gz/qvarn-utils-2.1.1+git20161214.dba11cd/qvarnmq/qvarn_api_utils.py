from qvarnmq import Helpers, QvarnException, QvarnResourceNotFoundException


class QvarnApiUtils(object):
    def __init__(self, qvarnclient):
        self._qvarnclient = qvarnclient

    ######################
    # SPECIFIC FUNCTIONS #
    ######################

    def get_available_job_ids(self, job_types):
        job_ids = []
        current_iso_time = Helpers.current_iso_time()

        for job_type in job_types:
            try:
                response = self._qvarnclient.resource(
                    'jobs').search().exact(
                    'job_type', job_type).exact(
                    'status', 'pending').less_than(
                    'reserved_until', current_iso_time).get().result()

                response.raise_for_status()
            except Exception:
                continue
            else:
                job_ids += Helpers.get_ids_from_response(response)

        return job_ids

    def list_jobs_by_type(self, job_type):
        try:
            response = self._qvarnclient.resource('jobs').search().exact(
                'job_type', job_type).get().result()

            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for fetching type %s job IDs failed' % job_type,
                response)

        job_ids = Helpers.get_ids_from_response(response)
        return self.get_resources_from_ids('jobs', job_ids)

    def list_jobs_by_organisation(self, org_id):
        try:
            response = self._qvarnclient.resource('jobs').search().exact(
                'org_id', org_id).get().result()

            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for fetching organisation %s job IDs failed' % (
                    org_id),
                response)

        job_ids = Helpers.get_ids_from_response(response)
        return self.get_resources_from_ids('jobs', job_ids)

    #####################
    # GENERIC FUNCTIONS #
    #####################

    def get_resources_from_ids(self, resource_type, resource_ids):
        requests = []
        resources = []

        for resource_id in resource_ids:
            future = self._qvarnclient.resource(
                resource_type).single(resource_id).get()

            requests.append({
                'resource_id': resource_id,
                'future': future,
            })

        for request in requests:
            try:
                response = request['future'].result()
                if response.status_code == 404:
                    continue

                response.raise_for_status()
            except Exception:
                raise QvarnException(
                    'Qvarn request for resource %s of type %s failed' % (
                        request['resource_id'], resource_type),
                    response)

            resources.append(response.json())

        return resources

    def get_resource_ids(self, resource_type):
        try:
            response = self._qvarnclient.resource(resource_type).get().result()
            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for resource IDs of type %s failed' % (
                    resource_type),
                response)

        resource_ids = [res['id'] for res in response.json()['resources']]
        return resource_ids

    def get_resources(self, resource_type):
        resource_ids = self.get_resource_ids(resource_type)
        resources = self.get_resources_from_ids(resource_type, resource_ids)

        return resources

    def get_resource(self, resource_type, resource_id):
        try:
            response = self._qvarnclient.resource(
                resource_type).single(resource_id).get().result()

            if response.status_code != 404:
                response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for resource %s of type %s failed' % (
                    resource_id, resource_type),
                response)

        if response.status_code == 404:
            raise QvarnResourceNotFoundException(
                'Resource %s of type %s was not found' % (
                    resource_id, resource_type),
                response)

        return response.json()

    def create_resource(self, resource_type, data):
        try:
            response = self._qvarnclient.resource(
                resource_type).post(data).result()
            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for creating resource of type %s failed' % (
                    resource_type),
                response)

        return response.json()

    def delete_resource(self, resource_type, resource_id):
        try:
            response = self._qvarnclient.resource(
                resource_type).single(resource_id).delete().result()
            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for deleting resource %s of type %s failed' % (
                    resource_id, resource_type),
                response)

    def update_resource(self, resource_type, resource_id, resource):
        try:
            response = self._qvarnclient.resource(
                resource_type).single(resource_id).put(resource).result()
            response.raise_for_status()
        except Exception:
            raise QvarnException(
                'Qvarn request for updating resource %s of type %s failed' % (
                    resource_id, resource_type),
                response)

        return response.json()

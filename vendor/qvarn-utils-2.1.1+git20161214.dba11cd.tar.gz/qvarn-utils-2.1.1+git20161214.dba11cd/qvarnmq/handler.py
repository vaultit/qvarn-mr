class Handler(object):
    def __init__(self, func):
        self.func = func

class QvarnMQException(Exception):
    pass


class QvarnException(QvarnMQException):
    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnException, self).__init__(message, response, *args)


class QvarnResourceNotFoundException(QvarnException):
    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnResourceNotFoundException, self).__init__(
            message, response, *args)

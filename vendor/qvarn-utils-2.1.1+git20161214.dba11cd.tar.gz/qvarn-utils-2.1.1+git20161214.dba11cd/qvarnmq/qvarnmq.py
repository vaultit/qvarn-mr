import datetime
import logging
import threading
import time

import dateutil.parser
from qvarnmq import (Handler, Helpers, Job, QvarnApiUtils, QvarnException,
                     Worker)


class QvarnMQ(object):
    def __init__(self, qvarnclient,
                 polling_interval=10, max_workers=5,
                 keep_alive_interval=5, reservation_chunk=10,
                 debug=False):
        self._qvarn_api_utils = QvarnApiUtils(qvarnclient)

        self._polling_interval = polling_interval
        self._max_workers = max_workers

        # This is required for some reason for INFO logs to appear
        logging.basicConfig(level=logging.INFO)

        self._logger = logging.getLogger('qvarnmq')
        self._logger.setLevel(logging.INFO)

        # Silence the logger if debug is not on
        self._logger.propagate = debug

        self._keep_alive_interval = keep_alive_interval
        self._reservation_chunk = reservation_chunk

        self._handlers = {}
        self._workers = {}

    ##########
    # PUBLIC #
    ##########

    def create_job(self, job_type, person_id=None, org_id=None, parameters={}):
        self._logger.info('Creating a job of type: %s', job_type)

        # THROWS: QvarnException
        job_resource = self._qvarn_api_utils.create_resource('jobs', {
            'job_type': job_type,
            'person_id': person_id,
            'org_id': org_id,
            'submitted_at': Helpers.current_iso_time(),
            'started_at': None,
            'done_at': None,
            # Set reserved_until to epoch initially to make sure that
            # datetime comparisons make it available
            'reserved_until': '1970-01-01T00:00:00+00:00',
            'status': 'pending',
            'parameters': Helpers.parameters_to_qvarn(parameters)
        })

        job = Job(self._qvarn_api_utils, job_resource)
        return job

    def restart_job(self, job_id):
        # THROWS: QvarnException
        job_resource = self._qvarn_api_utils.get_resource('jobs', job_id)

        job_resource.update({
            'status': 'pending',
            'reserved_until': '1970-01-01T00:00:00+00:00',
            'started_at': None,
            'done_at': None
        })

        # THROWS: QvarnException
        new_job_resource = self._qvarn_api_utils.update_resource(
            'jobs', job_id, job_resource)
        job = Job(self._qvarn_api_utils, new_job_resource)

        return job

    def get_job(self, job_id):
        self._logger.info('Fetching job with ID: %s', job_id)

        # THROWS: QvarnException
        job_resource = self._qvarn_api_utils.get_resource('jobs', job_id)
        job = Job(self._qvarn_api_utils, job_resource)

        return job

    def list_jobs_by_type(self, job_type):
        self._logger.info('Listing jobs of type: %s', job_type)

        # THROWS: QvarnException
        job_resources = self._qvarn_api_utils.list_jobs_by_type(job_type)
        jobs = [
            Job(self._qvarn_api_utils, job_resource)
            for job_resource in job_resources
        ]

        return jobs

    def list_jobs_by_organisation(self, org_id):
        self._logger.info('Listing jobs for organisation ID: %s', org_id)

        # THROWS: QvarnException
        job_resources = self._qvarn_api_utils.list_jobs_by_organisation(org_id)
        jobs = [
            Job(self._qvarn_api_utils, job_resource)
            for job_resource in job_resources
        ]

        return jobs

    def register_handler(self, job_type, func):
        self._handlers[job_type] = Handler(func)
        self._logger.info(
            'Registered function %s as handler for %s',
            func.__name__, job_type)

    def start(self):
        self._logger.info('Starting QvarnMQ')

        main_threads = []

        thread = threading.Thread(target=self._consume_jobs_from_qvarn)
        thread.start()
        main_threads.append(thread)

        self._logger.info('Qvarn job consuming thread started')

        thread = threading.Thread(target=self._keep_qvarn_jobs_alive)
        thread.start()
        main_threads.append(thread)

        self._logger.info('Qvarn job keep-alive thread started')

        # Block until all threads have finished, i.e. forever
        for main_thread in main_threads:
            main_thread.join()

    ###########
    # PRIVATE #
    ###########

    def _consume_jobs_from_qvarn(self):
        self._logger.info('Starting job consuming')

        while True:
            if len(self._workers) >= self._max_workers:
                self._logger.info('Out of workers, skipping polling')
                continue

            self._logger.info('Polling Qvarn')

            # Find jobs that are not reserved

            job_types = self._handlers.keys()
            job_ids = self._qvarn_api_utils.get_available_job_ids(job_types)
            self._logger.info('Found %d eligible jobs', len(job_ids))

            # Loop through the available jobs
            for job_id in job_ids:
                try:
                    job_resource = self._qvarn_api_utils.get_resource(
                        'jobs', job_id)
                except QvarnException:
                    self._logger.warning(
                        'Failed to fetch job %s from Qvarn, skipping', job_id)
                    continue

                job = Job(self._qvarn_api_utils, job_resource)

                # Make sure that the job was not reserved between the search
                # and the resource fetch
                reserved_until = dateutil.parser.parse(job.reserved_until)

                current_time = Helpers.current_time()
                if reserved_until > current_time:
                    self._logger.warning('Attempted to take a reserved job')
                    continue

                handler = self._handlers.get(job.job_type)

                # This should never happen, but lets make sure
                if not handler or not callable(handler.func):
                    self._logger.warning(
                        'Skipping job of type %s, no valid handler registered',
                        job.job_type)
                    continue

                new_reserved_until = current_time + datetime.timedelta(
                    seconds=self._reservation_chunk)

                job.update({
                    'status': 'in_progress',
                    'started_at': current_time.isoformat(),
                    'reserved_until': new_reserved_until.isoformat()
                })

                # Reserve the job

                try:
                    job.update_to_qvarn()
                except QvarnException:
                    self._logger.exception(
                        'Failed to reserve job %s from Qvarn, skipping',
                        job.id)
                    continue

                self._logger.info(
                    'Launching worker to handle job %s of type %s',
                    job.id, job.job_type)

                thread = threading.Thread(
                    target=self._handle_job,
                    args=(handler, job))

                worker = Worker(thread, job)

                self._workers[job.id] = worker
                worker.thread.start()

                self._logger.info('Added worker for job %s', job.id)

            time.sleep(self._polling_interval)

        self._logger.warning(
            'Exited job consume loop, waiting for jobs to finish')

        for worker in self._workers.values():
            worker.thread.join()

    def _keep_qvarn_jobs_alive(self):
        self._logger.info('Starting keep-alive checks')

        while True:
            for worker in self._workers.values():
                thread = worker.thread
                job = worker.job

                # We shouldn't have dead threads in our dictionary
                # but just making sure no race conditions apply
                if thread.is_alive():
                    # Add twice the keep alive interval in order to be more
                    # confident that delays do not allow the job to expire
                    current_time = Helpers.current_time()
                    next_check_with_leeway = current_time + datetime.timedelta(
                        seconds=self._keep_alive_interval * 2)

                    reserved_until = dateutil.parser.parse(job.reserved_until)

                    # NOTE: this is a reactive approach, i.e. only update
                    # the reserved_until if it's close to expiring.
                    # This could also be proactive, i.e. on every keep-alive
                    # check run it would update the reserved_until.
                    if reserved_until > next_check_with_leeway:
                        continue

                    new_reserved_until = reserved_until + datetime.timedelta(
                        seconds=self._reservation_chunk)

                    job.update({
                        'reserved_until': new_reserved_until.isoformat()
                    })

                    try:
                        job.update_to_qvarn()
                    except QvarnException:
                        self._logger.warning(
                            'Failed to keep-alive job %s in Qvarn, skipping',
                            job.id)
                        continue

                    self._logger.info('Kept job %s alive' % job.id)

            time.sleep(self._keep_alive_interval)

        self._logger.info('Exited keep-alive check loop')

    def _handle_job(self, handler, job):
        self._logger.info('Handling job %s of type %s', job.id, job.job_type)

        try:
            handler.func(job)
        except Exception:
            self._logger.exception('Job threw an exception')

            job.update({
                'status': 'failed'
            })

            try:
                job.update_to_qvarn()
            except QvarnException:
                self._logger.warning(
                    'Failed to set job %s to failed in Qvarn, skipping',
                    job.id)
            else:
                self._logger.info('Updated failed job %s', job.id)
        else:
            self._logger.info('Handler returned, updating job resource')

            job.update({
                'status': 'done',
                'done_at': Helpers.current_iso_time()
            })

            try:
                job.update_to_qvarn()
            except QvarnException:
                self._logger.warning(
                    'Failed to set result for job %s in Qvarn, skipping',
                    job.id)
            else:
                self._logger.info('Updated finished job %s', job.id)
        finally:
            self._logger.info(
                'Finished handling job %s of type %s', job.id, job.job_type)

            self._workers.pop(job.id)
            self._logger.info('Removed thread for job %s', job.id)

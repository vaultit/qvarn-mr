class Worker(object):
    def __init__(self, thread, job):
        self.thread = thread
        self.job = job

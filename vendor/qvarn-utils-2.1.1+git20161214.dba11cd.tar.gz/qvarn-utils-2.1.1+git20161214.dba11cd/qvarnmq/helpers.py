import datetime


class Helpers(object):
    @staticmethod
    def current_time():
        return datetime.datetime.now(datetime.timezone.utc)

    @staticmethod
    def current_iso_time():
        return Helpers.current_time().isoformat()

    @staticmethod
    def get_ids_from_response(response):
        return [resource['id'] for resource in response.json()['resources']]

    @staticmethod
    def parameters_from_qvarn(parameters):
        return {
            parameter['key']: parameter['value']
            for parameter in parameters
        }

    @staticmethod
    def parameters_to_qvarn(parameters):
        return [
            {'key': key, 'value': value}
            for (key, value) in parameters.items()
        ]

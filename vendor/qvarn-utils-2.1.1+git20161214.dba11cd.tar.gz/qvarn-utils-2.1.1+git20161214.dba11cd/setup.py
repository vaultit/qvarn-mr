#!/usr/bin/python
#
# setup.py - standard Python build-and-package program
#
# Copyright 2015 Suomen Tilaajavastuu Oy
# All rights reserved.


from distutils.core import setup


setup(
    name='qvarn-utils',
    version='2.1.1+git20161214.dba11cd',
    description='Qvarn utils',
    author='Suomen Tilaajavastuu Oy',
    author_email='tilaajavastuu.hifi@tilaajavastuu.fi',
    packages=['qvarnclient', 'qvarnmq'],
)

import unittest

import qvarnclient


class RequestsMock(object):

    def get(self, *args, **kwargs):
        return ('GET', args, kwargs)

    def post(self, *args, **kwargs):
        return ('POST', args, kwargs)

    def put(self, *args, **kwargs):
        return ('PUT', args, kwargs)

    def delete(self, *args, **kwargs):
        return ('DELETE', args, kwargs)


class ResponseMock(object):

    def __init__(self, data):
        self.data = data

    def json(self):
        return self.data


class QvarnClientTestCase(unittest.TestCase):

    def setUp(self):
        self._requests = RequestsMock()
        self._client = qvarnclient.QvarnClient('https://test', self._requests)


class QvarnClientHelperTests(QvarnClientTestCase):

    def test_parse_resource_ids(self):
        response = ResponseMock({
            'resources': [
                {'id': 'FOO'},
                {'id': 'BAR'}
            ]
        })

        self.assertEqual(
            tuple(self._client.parse_resource_ids(response)),
            ('FOO', 'BAR'))

    def test_get_resources_from_ids(self):
        pass

    def test_get_resources(self):
        pass

    def test_get_resource(self):
        pass

    def test_create_resource(self):
        pass

    def test_delete_resource(self):
        pass

    def test_update_resource(self):
        pass


class QvarnClientListResourceTests(QvarnClientTestCase):

    def test_get_resources(self):
        result = self._client.resource('cards').get()
        self.assertEqual(result, ('GET', ('https://test/cards',), {}))

    def test_post_resources(self):
        data = {'names': 'test', 'something': 'else'}
        result = self._client.resource('cards').post(data)
        self.assertEqual(result, (
            'POST', ('https://test/cards',),
            {'headers': {'Content-Type': 'application/json'}, 'json': data}
        ))


class QvarnClientSearchTests(QvarnClientTestCase):

    def test_search_single_exact_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .exact('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/key/value',),
             {}))

    def test_search_single_equal_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .equal('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/key/value',),
             {}))

    def test_search_single_eq_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .eq('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/key/value',),
             {}))

    def test_search_single_ne_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .ne('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/ne/key/value',),
             {}))

    def test_search_single_not_equal_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .not_equal('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/ne/key/value',),
             {}))

    def test_search_single_gt_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .gt('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/gt/key/value',),
             {}))

    def test_search_single_greater_than_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .greater_than('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/gt/key/value',),
             {}))

    def test_search_single_ge_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .ge('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/ge/key/value',),
             {}))

    def test_search_single_greater_than_or_equal_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .greater_than_or_equal('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/ge/key/value',),
             {}))

    def test_search_single_lt_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .lt('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/lt/key/value',),
             {}))

    def test_search_single_less_than_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .less_than('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/lt/key/value',),
             {}))

    def test_search_single_le_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .le('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/le/key/value',),
             {}))

    def test_search_single_less_than_or_equal_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .less_than_or_equal('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/le/key/value',),
             {}))

    def test_search_single_contains_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .contains('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/contains/key/value',),
             {}))

    def test_search_single_startswith_condition(self):
        result = (
            self._client.resource('cards')
            .search()
            .startswith('key', 'value').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/startswith/key/value',),
             {}))

    def test_search_multiple_conditions(self):
        result = (
            self._client.resource('cards')
            .search()
            .exact('key', 'value')
            .ne('key2', 'value2')
            .get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/key/value/ne/key2/value2',),
             {}))

    def test_search_with_show(self):
        result = (
            self._client.resource('cards')
            .search()
            .exact('k', 'v')
            .show('show_key').get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/k/v/show/show_key',),
             {}))

    def test_search_with_show_all(self):
        result = (
            self._client.resource('cards')
            .search()
            .exact('k', 'v')
            .show_all().get()
        )
        self.assertEqual(
            result,
            ('GET',
             ('https://test/cards/search/exact/k/v/show_all',),
             {}))


class QvarnClientSingleResourceTests(QvarnClientTestCase):

    def test_get_resource(self):
        result = self._client.resource('cards').single('id').get()
        self.assertEqual(result, ('GET', ('https://test/cards/id',), {}))

    def test_update_resource(self):
        data = {'names': 'test', 'something': 'else'}
        result = self._client.resource('cards').single('id').put(data)
        self.assertEqual(result, (
            'PUT', ('https://test/cards/id',),
            {'headers': {'Content-Type': 'application/json'}, 'json': data}))

    def test_delete_resource(self):
        result = self._client.resource('cards').single('id').delete()
        self.assertEqual(result, ('DELETE', ('https://test/cards/id',), {}))


class QvarnClientSubResourceTests(QvarnClientTestCase):

    def test_get_subresource(self):
        result = (
            self._client.resource('cards')
            .single('id').subresource('hello').get()
        )
        self.assertEqual(
            result, ('GET', ('https://test/cards/id/hello',), {}))

    def test_update_subresource(self):
        data = {'names': 'test', 'something': 'else'}
        result = (
            self._client.resource('cards')
            .single('id').subresource('hello').put(data)
        )
        self.assertEqual(result, (
            'PUT', ('https://test/cards/id/hello',),
            {'headers': {'Content-Type': 'application/json'}, 'json': data}))

    def test_update_filesubresource(self):
        data = 'testi'
        result = (
            self._client.resource('cards')
            .single('id').filesubresource('hello').put(
                data, 'image/png', 'revision')
        )
        self.assertEqual(result, (
            'PUT', ('https://test/cards/id/hello',),
            {
                'headers': {
                    'Content-Type': 'image/png',
                    'Revision': 'revision'
                },
                'data': data
            }
        ))

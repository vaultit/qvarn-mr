import urllib.parse

from qvarnclient import (QvarnBadRequestError, QvarnBatch, QvarnConflictError,
                         QvarnError, QvarnResourceNotFoundError)


class UrlBuilder(object):

    def __init__(self, url, requests):
        self._url = url
        self._requests = requests


class QvarnClient(object):

    def __init__(self, base_url, requests):
        self._base_url = base_url
        self._requests = requests

    def resource(self, resource_name):
        new_url = '{}/{}'.format(self._base_url, resource_name)
        return ListResource(new_url, self._requests)

    # Helper methods

    def batch(self):
        return QvarnBatch(self._base_url, self._requests)

    def parse_resource_ids(self, response):
        for resource in response.json()['resources']:
            yield resource['id']

    def get_resources_from_ids(self, resource_name, resource_ids,
                               strict=False):
        batch = self.batch()
        for resource_id in resource_ids:
            batch.resource(resource_name).single(resource_id).get()

        for result in batch.fetch(strict=strict):
            yield result.resource

    def get_resources(self, resource_name, strict=False):
        response = None

        try:
            response = self.resource(resource_name).get().result()
            response.raise_for_status()
        except Exception:
            raise QvarnError(
                'Qvarn request for all resources of type {} failed'.format(
                    resource_name), response)

        resource_ids = self.parse_resource_ids(response)

        batch = self.batch()
        for resource_id in resource_ids:
            batch.resource(resource_name).single(resource_id).get()

        for result in batch.fetch(strict=strict):
            yield result.resource

    def get_resource(self, resource_name, resource_id):
        response = None

        try:
            response = self.resource(resource_name).single(
                resource_id).get().result()

            if response.status_code != 404:
                response.raise_for_status()
        except Exception:
            raise QvarnError(
                'Qvarn request for resource {} of type {} failed'.format(
                    resource_id, resource_name), response)

        # Status code is either 2xx or 404 here
        if response.status_code == 404:
            raise QvarnResourceNotFoundError(
                'Qvarn resource {} of type {} was not found'.format(
                    resource_id, resource_name), response)

        return response.json()

    def create_resource(self, resource_name, data):
        response = None

        try:
            response = self.resource(resource_name).post(data).result()

            if response.status_code != 400:
                response.raise_for_status()
        except Exception:
            raise QvarnError(
                'Qvarn request for creating '
                'resource of type {} failed'.format(
                    resource_name), response)

        if response.status_code == 400:
            raise QvarnBadRequestError(
                'Qvarn request for creating '
                'resource of type {} failed due to incorrect data'.format(
                    resource_name), response)

        return response.json()

    def delete_resource(self, resource_name, resource_id):
        response = None

        try:
            response = self.resource(resource_name).single(
                resource_id).delete().result()

            response.raise_for_status()
        except Exception:
            raise QvarnError(
                'Qvarn request for deleting '
                'resource {} of type {} failed'.format(
                    resource_id, resource_name), response)

    def update_resource(self, resource_name, resource_id, resource):
        response = None

        try:
            response = self.resource(resource_name).single(
                resource_id).put(resource).result()

            if response.status_code != 409:
                response.raise_for_status()
        except Exception:
            raise QvarnError(
                'Qvarn request for updating '
                'resource %s of type %s failed'.format(
                    resource_id, resource_name), response)

        if response.status_code == 409:
            raise QvarnConflictError(
                'Qvarn request for creating '
                'resource of type {} failed due to incorrect revision'.format(
                    resource_name), response)

        return response.json()


class Gettable(UrlBuilder):

    def get(self):
        return self._requests.get(self._url)


class Postable(UrlBuilder):

    def post(self, data):
        headers = {'Content-Type': 'application/json'}
        return self._requests.post(self._url, json=data, headers=headers)


class Puttable(UrlBuilder):

    def put(self, data):
        headers = {'Content-Type': 'application/json'}
        return self._requests.put(self._url, json=data, headers=headers)


class FilePuttable(UrlBuilder):

    def put(self, data, content_type, revision):
        headers = {'Content-Type': content_type, 'Revision': revision}
        return self._requests.put(self._url, data=data, headers=headers)


class Deletable(UrlBuilder):

    def delete(self):
        return self._requests.delete(self._url)


class ListResource(Gettable, Postable):

    def search(self):
        new_url = '{}/search'.format(self._url)
        return ResourceSearch(new_url, self._requests)

    def single(self, resource_id):
        new_url = '{}/{}'.format(self._url, resource_id)
        return SingleResource(new_url, self._requests)


class ResourceSearch(Gettable, UrlBuilder):

    def exact(self, key, value):
        return self._cond_key_value('exact', key, value)

    def eq(self, key, value):
        return self.exact(key, value)

    def equal(self, key, value):
        return self.exact(key, value)

    def ne(self, key, value):
        return self._cond_key_value('ne', key, value)

    def not_equal(self, key, value):
        return self.ne(key, value)

    def gt(self, key, value):
        return self._cond_key_value('gt', key, value)

    def greater_than(self, key, value):
        return self.gt(key, value)

    def ge(self, key, value):
        return self._cond_key_value('ge', key, value)

    def greater_than_or_equal(self, key, value):
        return self.ge(key, value)

    def lt(self, key, value):
        return self._cond_key_value('lt', key, value)

    def less_than(self, key, value):
        return self.lt(key, value)

    def le(self, key, value):
        return self._cond_key_value('le', key, value)

    def less_than_or_equal(self, key, value):
        return self.le(key, value)

    def contains(self, key, value):
        return self._cond_key_value('contains', key, value)

    def startswith(self, key, value):
        return self._cond_key_value('startswith', key, value)

    def show_all(self):
        new_url = '{}/show_all'.format(self._url)
        return ResourceSearch(new_url, self._requests)

    def show(self, key):
        new_url = '{}/show/{}'.format(self._url, key)
        return ResourceSearch(new_url, self._requests)

    def _cond_key_value(self, cond, key, value):
        escaped_value = urllib.parse.quote(value, safe='')
        new_url = '{}/{}/{}/{}'.format(self._url, cond, key, escaped_value)
        return ResourceSearch(new_url, self._requests)


class SingleResource(Gettable, Puttable, Deletable):

    def subresource(self, subresource_name):
        new_url = '{}/{}'.format(self._url, subresource_name)
        return SubResource(new_url, self._requests)

    def filesubresource(self, subresource_name):
        new_url = '{}/{}'.format(self._url, subresource_name)
        return FileSubResource(new_url, self._requests)


class SubResource(Gettable, Puttable):

    pass


class FileSubResource(Gettable, FilePuttable):

    pass

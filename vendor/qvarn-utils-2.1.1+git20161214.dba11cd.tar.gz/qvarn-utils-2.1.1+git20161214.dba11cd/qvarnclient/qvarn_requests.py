import time
import jwt
from requests_futures.sessions import FuturesSession

import qvarnclient


class QvarnRequests(object):

    def __init__(self, base_url=None, client_id=None, client_secret=None,
                 scopes=None, verify_requests=True, max_workers=1):
        self._base_url = base_url
        self._session = FuturesSession(max_workers=max_workers)
        self._session.verify = verify_requests
        self._client_id = client_id
        self._client_secret = client_secret
        self._scopes = scopes
        self._expiry_time = None
        self._check_access_token()

    def set_scopes(self, scopes):
        self._scopes = scopes
        self._expiry_time = None
        self._check_access_token()

    def get(self, *args, **kwargs):
        self._check_access_token()
        return self._session.get(*args, **kwargs)

    def post(self, *args, **kwargs):
        self._check_access_token()
        return self._session.post(*args, **kwargs)

    def put(self, *args, **kwargs):
        self._check_access_token()
        return self._session.put(*args, **kwargs)

    def delete(self, *args, **kwargs):
        self._check_access_token()
        return self._session.delete(*args, **kwargs)

    def _check_access_token(self):
        now = time.time()
        if not self._expiry_time or self._expiry_time <= now:
            token_response = self._session.post(
                '{}/auth/token'.format(self._base_url),
                {
                    'grant_type': 'client_credentials',
                    'scope': ' '.join(self._scopes),
                },
                auth=(self._client_id, self._client_secret)).result()

            if token_response.status_code != 200:
                raise qvarnclient.TokenRequestError('{} {}'.format(
                    token_response.status_code, token_response.text))

            auth_data = token_response.json()
            given_scopes = auth_data['scope'].split()
            missing_scopes = set(self._scopes).difference(set(given_scopes))
            if missing_scopes:
                raise qvarnclient.ScopesMissingError(
                    ' '.join(missing_scopes))

            access_token = auth_data['access_token']
            decoded_token = jwt.decode(access_token, verify=False)
            self._expiry_time = decoded_token.get('exp')
            self._session.headers.update({
                'Authorization': 'Bearer {}'.format(access_token)
            })

class NoResultsException(Exception):

    pass


class MockRequest(object):

    def __init__(self, response):
        self._response = response

    def result(self):
        return self._response


class MockResponse(object):

    def __init__(self, contents):
        self._contents = contents

    @property
    def status_code(self):
        return self._contents['status_code']

    def json(self):
        return self._contents['json']

    @property
    def text(self):
        return self._contents['text']


class MockRequests(object):

    def __init__(self):
        self._results = []
        self._calls = []

    def get_calls(self):
        return self._calls

    def add_result(self, result):
        self._results.append(result)

    def set_results(self, results):
        self._results = results

    def get_results(self):
        return self._results

    def _get_next_result(self):
        if not self._results:
            raise NoResultsException(
                'Not enough results for calls %r' % self._calls)
        result = self._results[0]
        self._results = self._results[1:]
        return MockRequest(MockResponse(result))

    def get(self, *args, **kwargs):
        self._calls.append(('GET', args, kwargs))
        return self._get_next_result()

    def post(self, *args, **kwargs):
        self._calls.append(('POST', args, kwargs))
        return self._get_next_result()

    def put(self, *args, **kwargs):
        self._calls.append(('PUT', args, kwargs))
        return self._get_next_result()

    def delete(self, *args, **kwargs):
        self._calls.append(('DELETE', args, kwargs))
        return self._get_next_result()

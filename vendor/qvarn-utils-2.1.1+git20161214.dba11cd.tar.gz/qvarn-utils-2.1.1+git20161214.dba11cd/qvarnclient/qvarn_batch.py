import urllib.parse
import uuid

from qvarnclient import QvarnError, QvarnResourceNotFoundError


class BatchUrlBuilder(object):

    def __init__(self, url, requests, batch_future):
        self._url = url
        self._requests = requests
        self._batch_future = batch_future

    def set_resource_id(self, resource_id):
        self._batch_future.resource_id = resource_id
        return self

    def set_resource_name(self, resource_name):
        self._batch_future.resource_name = resource_name
        return self


class BatchResponse(object):
    def __init__(self, resource_name, resource_id, resource):
        self.id = resource_id
        self.type = resource_name
        self.resource = resource


class BatchFuture(object):
    def __init__(self, future_id=None, future=None,
                 resource_name=None, resource_id=None):
        self.id = future_id
        self.resource_id = resource_id
        self.resource_name = resource_name
        self.future = future


class QvarnBatch(object):

    def __init__(self, base_url, requests):
        self._base_url = base_url
        self._requests = requests

        self._batch_futures = []

    def resource(self, resource_name):
        new_url = '{}/{}'.format(self._base_url, resource_name)

        batch_future = BatchFuture(
            future_id=str(uuid.uuid4()),
            resource_name=resource_name)

        self._batch_futures.append(batch_future)
        return ListResource(new_url, self._requests, batch_future)

    def fetch(self, strict=False):
        batch_futures = []
        for batch_future in self._batch_futures:
            resource_id = batch_future.resource_id
            resource_name = batch_future.resource_name
            future = batch_future.future

            try:
                # If we're handling a future, handle it later
                if hasattr(future, 'result') and callable(future.result):
                    batch_futures.append(batch_future)
                    continue

                # Futures not supported, yield the response instantly
                response = future
                if response.status_code == 404:
                    if not strict:
                        continue

                    raise QvarnResourceNotFoundError(
                        'Qvarn resource {} of type {} was not found'.format(
                            resource_id, resource_name), response)

                response.raise_for_status()
                yield BatchResponse(
                    resource_name, resource_id, response.json())
            except Exception:
                raise QvarnError(
                    'Qvarn request for resource {} of type {} failed'.format(
                        resource_id, resource_name), response)

        for batch_future in batch_futures:
            resource_id = batch_future.resource_id
            resource_name = batch_future.resource_name
            future = batch_future.future

            response = None

            try:
                response = future.result()
                if response.status_code == 404:
                    if not strict:
                        continue

                    raise QvarnResourceNotFoundError(
                        'Qvarn resource {} of type {} was not found'.format(
                            resource_id, resource_name),
                        response)

                response.raise_for_status()
            except Exception:
                for batch_future in batch_futures:
                    batch_future.future.cancel()

                raise QvarnError(
                    'Qvarn request for resource {} of type {} failed'.format(
                        resource_id, resource_name),
                    response)

            try:
                yield BatchResponse(
                    resource_name, resource_id, response.json())
            except GeneratorExit:
                for batch_future in batch_futures:
                    batch_future.future.cancel()

                return


class Gettable(BatchUrlBuilder):

    def get(self):
        self._batch_future.future = self._requests.get(self._url)
        return self._batch_future.future


class Postable(BatchUrlBuilder):

    def post(self, data):
        headers = {'Content-Type': 'application/json'}

        self._batch_future.future = self._requests.post(
            self._url, json=data, headers=headers)
        return self._batch_future.future


class Puttable(BatchUrlBuilder):

    def put(self, data):
        headers = {'Content-Type': 'application/json'}

        self._batch_future.future = self._requests.put(
            self._url, json=data, headers=headers)
        return self._batch_future.future


class FilePuttable(BatchUrlBuilder):

    def put(self, data, content_type, revision):
        headers = {'Content-Type': content_type, 'Revision': revision}

        self._batch_future.future = self._requests.put(
            self._url, data=data, headers=headers)
        return self._batch_future.future


class Deletable(BatchUrlBuilder):

    def delete(self):
        self._batch_future.future = self._requests.delete(self._url)
        return self._batch_future.future


class ListResource(Gettable, Postable):

    def search(self):
        new_url = '{}/search'.format(self._url)
        return ResourceSearch(new_url, self._requests, self._batch_future)

    def single(self, resource_id):
        new_url = '{}/{}'.format(self._url, resource_id)

        self._batch_future.resource_id = resource_id
        return SingleResource(new_url, self._requests, self._batch_future)


class ResourceSearch(Gettable, BatchUrlBuilder):

    def exact(self, key, value):
        return self._cond_key_value('exact', key, value)

    def eq(self, key, value):
        return self.exact(key, value)

    def equal(self, key, value):
        return self.exact(key, value)

    def ne(self, key, value):
        return self._cond_key_value('ne', key, value)

    def not_equal(self, key, value):
        return self.ne(key, value)

    def gt(self, key, value):
        return self._cond_key_value('gt', key, value)

    def greater_than(self, key, value):
        return self.gt(key, value)

    def ge(self, key, value):
        return self._cond_key_value('ge', key, value)

    def greater_than_or_equal(self, key, value):
        return self.ge(key, value)

    def lt(self, key, value):
        return self._cond_key_value('lt', key, value)

    def less_than(self, key, value):
        return self.lt(key, value)

    def le(self, key, value):
        return self._cond_key_value('le', key, value)

    def less_than_or_equal(self, key, value):
        return self.le(key, value)

    def contains(self, key, value):
        return self._cond_key_value('contains', key, value)

    def startswith(self, key, value):
        return self._cond_key_value('startswith', key, value)

    def show_all(self):
        new_url = '{}/show_all'.format(self._url)
        return ResourceSearch(new_url, self._requests, self._batch_future)

    def show(self, key):
        new_url = '{}/show/{}'.format(self._url, key)
        return ResourceSearch(new_url, self._requests, self._batch_future)

    def _cond_key_value(self, cond, key, value):
        escaped_value = urllib.parse.quote(value, safe='')
        new_url = '{}/{}/{}/{}'.format(self._url, cond, key, escaped_value)
        return ResourceSearch(new_url, self._requests, self._batch_future)


class SingleResource(Gettable, Puttable, Deletable):

    def subresource(self, subresource_name):
        new_url = '{}/{}'.format(self._url, subresource_name)

        self._batch_future.resource_name += '_%s' % subresource_name
        return SubResource(new_url, self._requests, self._batch_future)

    def filesubresource(self, subresource_name):
        new_url = '{}/{}'.format(self._url, subresource_name)

        self._batch_future.resource_name += '_%s' % subresource_name
        return FileSubResource(new_url, self._requests, self._batch_future)


class SubResource(Gettable, Puttable):

    pass


class FileSubResource(Gettable, FilePuttable):

    pass

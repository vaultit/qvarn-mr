class QvarnClientError(Exception):

    pass


class ScopesMissingError(QvarnClientError):

    pass


class TokenRequestError(QvarnClientError):

    pass


class QvarnError(QvarnClientError):

    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnError, self).__init__(message, response, *args)


class QvarnResourceNotFoundError(QvarnError):

    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnResourceNotFoundError, self).__init__(
            message, response, *args)


class QvarnBadRequestError(QvarnError):

    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnBadRequestError, self).__init__(
            message, response, *args)


class QvarnConflictError(QvarnError):

    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnConflictError, self).__init__(
            message, response, *args)


class QvarnMultipleFoundError(QvarnError):

    def __init__(self, message, response, *args):
        self.message = message
        self.response = response

        super(QvarnMultipleFoundError, self).__init__(
            message, response, *args)

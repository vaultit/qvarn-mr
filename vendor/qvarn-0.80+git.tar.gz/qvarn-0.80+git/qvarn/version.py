__version__ = "0.80+git"
__version_info__ = (0, 80, '+git')

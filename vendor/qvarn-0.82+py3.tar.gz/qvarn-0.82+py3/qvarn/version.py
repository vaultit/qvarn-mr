__version__ = "0.82+py3"
__version_info__ = (0, 82)
